﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceReference1.Service2Client client = new ServiceReference1.Service2Client();

            try
            {
                Console.WriteLine(client.division(34, 0)); 
            }
            catch(FaultException<ServiceReference1.CustomException> e)
            {
                Console.WriteLine(e.Detail.title);
                Console.WriteLine(e.Detail.ErrorMessage);
                Console.WriteLine(e.Detail.ErrorCode);
                Console.ReadLine();
            }
        }
    }
}
