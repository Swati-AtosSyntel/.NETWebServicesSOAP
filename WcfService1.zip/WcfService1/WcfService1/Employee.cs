﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace WcfService1
{
    [DataContract]
    public class Employee
    {
        [DataMember(Name ="EmployeeID", Order=2)]
        public int eid { get; set; }
        [DataMember(Name = "EmployeeName", Order = 1)]
        public string ename { get; set; }

        public static List<Employee> GetEmployees()
        {
            List<Employee> list = new List<Employee>()
            {
                new Employee{eid=123,ename="Swati"},
                new Employee{eid=124,ename="Prashant"},
                new Employee{eid=125,ename="Jyoti"}
            };
            return list;
        }
    }
}