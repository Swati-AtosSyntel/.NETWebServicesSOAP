﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WcfService1
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service2" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service2.svc or Service2.svc.cs at the Solution Explorer and start debugging.
    public class Service2 : IService2
    {
        public int CalculateSum(int a, int b)
        {
            return (a + b);
        }

       

        public Employee serach(int id)
        {
            return Employee.GetEmployees().SingleOrDefault(emp => emp.eid == id);
        }

        public string ShowMessage(string msg)
        {
            return "Hi, This is WCF Service!!!";
        }
        public int division(int a, int b)
        {
            CustomException ex = new CustomException()
            {
                title = "Division Error!!!",
                ErrorCode = "504",
                ErrorMessage = "You are trying to divide number by zero"
            };
            throw new FaultException<CustomException>(ex,"Reason:Error while dividing the number");
        }
    }
}
